This test sets some EIP-7702 delegations and calls them.
